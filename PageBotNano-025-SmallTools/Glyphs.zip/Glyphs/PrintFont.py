
f = Glyphs.font
print(f)