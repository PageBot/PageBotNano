#
#	PageBot Nano
#
#	elements.py
#
#	This source contains the class with knowledge about elements that
#	can be placed on a page.
#
class Element:
	# Class names start with a capital. See a class as a factory
	# of element objects (name spelled with an initial lower case.)
	pass # For now it will do nothing, but that will change.