**(Use MacDown to view this document)**

# PageBotNano #006
PageBotNano is a top-down evolving light-weight training version of PageBot. It is not compatible, but shares the same structure. 

## Relation between classes

![](gallery/DocumentPagesElements.pdf)

## New to this version

* Add Image element for scaleable images.
* Add image on cover of the type specimen example.
* Add resource fodler with some example images.

## Gallery

![](gallery/MyTypeSpecimen.pdf)

